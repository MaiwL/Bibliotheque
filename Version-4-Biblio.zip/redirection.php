<?php require_once 'admin.php'; ?>
<?php require_once 'EnsembleLivres.php' ; ?>
<?php 
class Redirection extends EnsembleLivres {
    public
}
?>